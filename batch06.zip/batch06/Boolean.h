/*
*Batch Number 6
*Abhinav Bhatia (2011A7PS371P)
*Mukul Bhutani (2011A7PS343P)
*/
#ifndef _CUSTOMBOOLEAN_H_
#define _CUSTOMBOOLEAN_H_

typedef enum
{
	TRUE = 1,
	FALSE = 0
} Boolean;

#endif