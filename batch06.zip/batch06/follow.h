/*
*Batch Number 6
*Abhinav Bhatia (2011A7PS371P)
*Mukul Bhutani (2011A7PS343P)
*/
#ifndef _FOLLOW_H_
#define _FOLLOW_H_

#include "definitions.h"

HashSet follow(Symbol* nonTerminal, Grammar g);


#endif