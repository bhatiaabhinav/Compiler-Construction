#ifndef _CODEGENERATOR_DEF_H_
#define _CODEGENERATOR_DEF_H_
#include <stdio.h>

char reg[4][5];
int isRegisterEmpty[4];
int labelNum;
char dataSegmentInfo[2000];
char codeSegmentInfo[5000];
FILE dataPtr;

#endif