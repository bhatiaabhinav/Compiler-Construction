/*
*Batch Number 6
*Abhinav Bhatia (2011A7PS371P)
*Mukul Bhutani (2011A7PS343P)
*/
#ifndef _STDAFX_H_
#define _STDAFX_H_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#endif