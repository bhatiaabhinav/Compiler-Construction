/*
*Batch Number 6
*Abhinav Bhatia (2011A7PS371P)
*Mukul Bhutani (2011A7PS343P)
*/
#ifndef _CONSTANTS_H_
#define _CONSTANTS_H_

#define MAX_WORD 50
#define MAX_NO_RHS 20
#define LINE_LENGTH 1024
#define MAX_NO_SYMBOLS 100
#define NO_RULES 90
#define MAX_LEXEME_SIZE 50

#define SYMBOL_TABLE_SIZE 31
#define FUNCTION_SYMBOL_TABLE_SIZE 19

#endif