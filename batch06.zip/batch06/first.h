/*
*Batch Number 6
*Abhinav Bhatia (2011A7PS371P)
*Mukul Bhutani (2011A7PS343P)
*/
#ifndef _FIRST_H_
#define _FIRST_H_

#include "definitions.h"

HashSet first(LinkList stringOfSymbols, Grammar grammar);

#endif



