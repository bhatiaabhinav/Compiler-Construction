/*
*Batch Number 6
*Abhinav Bhatia (2011A7PS371P)
*Mukul Bhutani (2011A7PS343P)
*/
#ifndef _COMMONS_H_
#define _COMMONS_H_

#include "stdafx.h"
#include "Boolean.h"
#include "DFA.h"
#include "linklist.h"
#include "HashTable.h"
#include "set.h"
#include "Tree.h"

#endif